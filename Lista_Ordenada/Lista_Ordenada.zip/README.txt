https://github.com/GabrielRodolfoR/Estrutura-de-Dados/tree/main

o projeto esta também no github na pasta Lista_Ordenada